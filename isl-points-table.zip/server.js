const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('public'));
app.use(express.json());

let pointsTable = [
  { name: "Team A", played: 3, won: 2, draw: 1, lost: 0, points: 7 },
  { name: "Team B", played: 3, won: 1, draw: 1, lost: 1, points: 4 }
];

const ADMIN = { username: "admin", password: "1234" };

app.get('/api/points', (req, res) => {
  res.json(pointsTable);
});

app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN.username && password === ADMIN.password) res.sendStatus(200);
  else res.sendStatus(401);
});

app.post('/api/admin/update', (req, res) => {
  const { name, played, won, draw, lost } = req.body;
  let team = pointsTable.find(t => t.name === name);
  if (team) {
    team.played = played;
    team.won = won;
    team.draw = draw;
    team.lost = lost;
    team.points = (won * 3) + (draw);
    res.sendStatus(200);
  } else {
    res.sendStatus(404);
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
